# pixxbind

Аугментации изображений на C++ с последующей обёрткой в Python (pybind11). 

Цель: реализовать функции обработки изображений на C++ (Step‑1), затем обернуть их в Python-модуль (Step‑2), упаковать (Step‑3), собрать wheel в Docker (Step‑4) и проверить корректность тестами (Step‑5).

## Статус на сегодня

- [2025‑11‑04] Выполнен Step‑1: C++ функции и базовая валидация входов

## Контракт и формат данных

- Тип: uint8, диапазон [0, 255]
- Формат: H × W × C, где C от 1 до 3
- Все функции создают и возвращают новый массив

## Начинка

- to_gray(img)
  - C==3: Y = round(0.299·R + 0.587·G + 0.114·B), clamp
  - C==1: возвращает копию

- brightness(img, delta:int)
  - x' = clamp(x + delta, 0, 255)

- contrast(img, alpha:float)
  - x' = clamp(round((x − 128)·alpha + 128), 0, 255)

- add_noise(img, amp:int, seed:uint64=0)
  - Равномерный шум
  - x' = clamp(x + noise, 0, 255)

- random_crop(img, out_h:int, out_w:int, seed:uint64=0)

- resize_pad(img, out_h:int, out_w:int, keep_aspect:bool=true, pad:uint8=0, bilinear:bool=false)


