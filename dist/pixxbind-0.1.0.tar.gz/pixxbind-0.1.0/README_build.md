# pixxbind: путь сборки и проверки

Ниже кратко, что было сделано и как повторить.

## 1. C++ и биндинги
- Реализованы аугментации в `src/pixxbind.cpp` и проверки ввода в `src/helpers.hpp` (uint8, H×W×C, C∈{1,3}).
- Экспортированы функции через `PYBIND11_MODULE(pixxbind_cpp, m)`.
- Python-обёртка `pixxbind/__init__.py` просто реэкспортирует функции из расширения.

## 2. Сборка и паковка (scikit-build-core)
- `pyproject.toml` настроен под scikit-build-core + pybind11 + numpy.
- `CMakeLists.txt` описывает модуль `pixxbind_cpp` и установки путей.
- `Makefile` (опционально) — цели `build` (python -m build) и `clean`.

## 3. Docker (Linux wheel)
- `Dockerfile` на базе `python:3.10-slim`:
  - Устанавливает build-essential, cmake, ninja.
  - Ставит зависимости: build, pytest, scikit-build-core, pybind11, numpy.
  - `python -m build` -> wheel в `dist/`.
  - `pip install dist/*.whl` для проверки импорта.
  - CMD: `pytest -q tests`.
- Сборка: `docker build -t pixxbind .`
- Запуск тестов: `docker run --rm pixxbind`.
- Wheel внутри образа: `dist/pixxbind-0.1.0-cp310-cp310-linux_x86_64.whl`.

## 4. Локальный Windows wheel
- Ставим toolchain (MinGW g++ или MSVC). Мы использовали g++ + Ninja.
- Пример команд (PowerShell):
  ```powershell
  cd "c:\Users\Artem Khakimov\Desktop\MIPT\mlops\pixxbind"
  $Env:CMAKE_GENERATOR="Ninja"
  $Env:CC="gcc"
  $Env:CXX="g++"
  python -m pip install --upgrade pip build scikit-build-core pybind11 numpy ninja
  python -m build
  ```
- Результат: `dist/pixxbind-0.1.0-cp314-cp314-win_amd64.whl` (аналогично можно собрать под другой CPython версии, например cp311, если стоит Python 3.11).

## 5. Тесты
- `tests/test_bindings.py` сравнивает результаты C++ функций с эталонными NumPy-реализациями.
- Запуск локально: `pytest -q` (после установки пакета в текущее окружение).

## 6. Демонстрационный ноутбук
- `demo_pixxbind.ipynb` — пошагово: установка wheel, проверки импорта, визуализация всех операций и сравнения с эталонными реализациями (OpenCV / NumPy).
- Ноутбук автоматически выбирает wheel из `dist/` по текущему ABI (`cpXY`). Если нужного файла нет — соберите его `python -m build` под своим Python.

## 7. Краткий порядок воспроизведения
- Linux (через Docker): `docker build -t pixxbind .` -> `docker run --rm pixxbind`.
- Windows локально:
  1) Собрать wheel под свой Python: `python -m build` (с настроенным компилятором).
  2) `pip install dist/pixxbind-<ver>-<abi>-win_amd64.whl`.
  3) `pytest -q` или запустить `demo_pixxbind.ipynb`.

## 8. Основные функции
- `to_gray`, `brightness`, `contrast`, `add_noise`, `random_crop`, `resize_pad` — все работают на `uint8` H×W×C, C=1 или 3, создают новый массив и насыщают значения в [0,255].
