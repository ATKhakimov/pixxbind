# pixxbind: что за что отвечает (дев-объяснение)

Это краткое описание всех файлов/шагов, которые мы сделали, и логики взаимодействия.

## Структура и роли
- `src/pixxbind.cpp` — C++ реализация аугментаций + pybind11-экспорт (`PYBIND11_MODULE`).
- `src/helpers.hpp` — утилиты: проверка формы/типов входа, сатурация значений.
- `pixxbind/__init__.py` — тонкая Python-обёртка: импортирует бинарный модуль `pixxbind_cpp` и реэкспортирует функции.
- `CMakeLists.txt` — описывает, как собрать расширение:
  - `find_package(pybind11 CONFIG REQUIRED)` — тянет pybind11.
  - `pybind11_add_module(pixxbind_cpp src/pixxbind.cpp)` — целевой модуль.
  - include dirs + `cxx_std_17` + install пути (в корень колеса).
- `pyproject.toml` — основной рецепт сборки пакета:
  - `[build-system]` — scikit-build-core, pybind11, numpy.
  - `[project]` — метаданные пакета.
  - `[tool.scikit-build]` — что упаковывать (wheel.packages), исключения, тип сборки.
  - `cmake.minimum-version` — минимальная версия CMake.
- `Makefile` — удобные цели: `build` (python -m build), `cpp` (cmake ..; build), `clean`.
- `Dockerfile` — воспроизводимая сборка Linux-колеса (python:3.10-slim):
  1) apt-get build-essential/cmake/ninja
  2) pip install build/pytest/scikit-build-core/pybind11/numpy
  3) `python -m build` -> wheel в `dist/`
  4) `pip install dist/*.whl`
  5) CMD: `pytest -q tests`
- `tests/test_bindings.py` — проверка результатов против NumPy эталонов.
- `demo_pixxbind.ipynb` — интерактивная демка, установка wheel + сравнение с OpenCV/NumPy.
- `README_build.md` — короткий гайд по сборке (Docker, Win, ноутбук).
- `README_dev.md` (этот файл) — пояснения.

## Логика взаимодействия
1) **Сборка расширения**: CMake через scikit-build-core вызывает pybind11, собирает `pixxbind_cpp` как разделяемую библиотеку (.pyd/.so). Устанавливается в корень колеса.
2) **Python-пакет**: пакет `pixxbind` содержит только `__init__.py`, который импортирует бинарный модуль. Функции доступны как обычные Python-функции.
3) **Сборка колеса**: `python -m build` читает `pyproject.toml`, дергает scikit-build-core, который вызывает CMake/Ninja и упаковывает артефакт в `dist/*.whl`.
4) **Тесты**: после установки колеса `pytest -q` прогоняет проверки против эталонов.
5) **Docker**: используется для гарантии чистой среды и получения Linux-колеса; внутри сразу ставим и гоняем тесты.
6) **Ноутбук**: подбирает wheel по текущему ABI (cpXY), ставит его, гоняет примеры и сравнивает с OpenCV/NumPy.

## Как собрать под свою версию Python (Windows пример)
```powershell
cd "c:\Users\Artem Khakimov\Desktop\MIPT\mlops\pixxbind"
$Env:CMAKE_GENERATOR="Ninja"
$Env:CC="gcc"
$Env:CXX="g++"
python -m pip install --upgrade pip build scikit-build-core pybind11 numpy ninja
python -m build
```
Wheel появится в `dist/` с тегом `cp<XY>` вашей версии Python.

## Мини-FAQ
- **Почему pybind11 + scikit-build-core?** Удобная сборка C++ расширений без setup.py, кроссплатформенно.
- **Зачем CMakeLists?** Описывает цели сборки и зависимости для C++. Его читает scikit-build-core.
- **Почему wheel в корне?** Чтобы `import pixxbind_cpp` работал без подкаталогов (install DESTINATION `.`).
- **Как сменить компилятор/генератор?** Через переменные окружения (`CC/CXX`, `CMAKE_GENERATOR`).
